# SphereAutomation
Selenium automation project for Sphere application
